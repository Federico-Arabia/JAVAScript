{console.log("INTRODUCCION_A_JAVASCRIPT");
  console.log("Ejercicio 1.2");
  let a = 3;
  let b = 5;
  let c = a + b;
  console.log("La suma de a y b es: ",c);
}
/*
console.log("-------------------------------");
{
  console.log("Ejercicio 1.3");
  const nombre = prompt("¿Cual es tu nombre?");
  console.log("Hola", nombre,"!");
  
}
console.log("-------------------------------");
console.log("Operadores logicos y condicionales");
console.log("-------------------------------");
{
  console.log("Ejercicio 2.1");
  let a = 30;
  let b = 33;
  let c = 50;
  console.log("a=",a,
     "b=", b,
     "c=",c);
  if (a>b && a>c){
    console.log("El mayor numero es: ",a);}
    else if (b>a && b>c){
      console.log("El mayor numero es: ",b);
    }
    else {
      console.log("El mayor numero es: ",c);
    }
}
console.log("-------------------------------");
{
  console.log("Ejercicio 2.2");
  const numero = prompt("Ingrese un numero");
  if (numero%2){
    console.log("El numero es impar");
  }
  else {
    console.log("El numero es par");
  }
}
console.log("-------------------------------");
console.log("Operadores de asignación y bucles");
console.log("-------------------------------");
{
  console.log("Ejercicio 3.1");
  let x=10
  while(x>0){
     console.log(x); x--;
  }
}
console.log("-------------------------------");
{
  console.log("Ejercicio 3.2");
 let numero2;
  do {
    numero2 = prompt("Ingrese un numero mayor a 100");
  } while (numero2<=100);
  console.log("Ingresaste un numero mayor a 100: ", numero2);
}
console.log("-------------------------------");
console.log("Funciones en JavaScript");
console.log("-------------------------------");
{
  console.log("Ejercicio 4.1");
  const esPar = (numero) => {
  if ((numero)%2 ==0){
    return true;
  }
  else {
    return false;
  }
}
let numero1= 4;
let numeroA= 5;
console.log("Primer numero=",numero1,",",
  "Segundo numero=", numeroA);
console.log("El numero ", numero1, "es Par ", esPar(numero1));
console.log("El numero ", numeroA , "es Impar", esPar(numeroA));
}
console.log("-------------------------------");
{
  console.log("Ejercicio 4.2");
  const convertirCelsiusAFahrenheit = (celsius) => {
    return celsius*1.8+32;
  }
  const numero = prompt("Ingrese Temperatura en Celsius"); 
  console.log(numero, "°C son equivalentes a ", convertirCelsiusAFahrenheit(numero), "°F");
}
console.log("-------------------------------");
console.log("Objetos en JavaScript");
console.log("-------------------------------");
{
  console.log("Ejercicio 5.1");
  let persona = {
    nombre: "Fede",
    Edad: 22,
    Ciudad: "Mendoza", 
    
    cambiociudad(Nuevaciudad){
    this.Ciudad= Nuevaciudad;
  }
    };

  console.log("Persona:",persona.nombre);
  console.log("Edad: " ,persona.Edad);
  console.log("Ciudad: " ,persona.Ciudad);
  persona.cambiociudad("Buenos Aires");
  console.log("NuevaCiudad: " ,persona.Ciudad);
}
console.log("-------------------------------");
{
  console.log("Ejercicio 5.2");
  let libro = {
    titulo: "Don quijote",
    autor: "Miguel de Cervantes",
    año: 1605, 
  
  esAntiguo: (año) =>{
    if(2024 - año > 10) return true;
    else return false;
  }
};
if(libro.esAntiguo(libro.año)){
  console.log("El libro '", libro.titulo, "' es antiguo: ", libro.esAntiguo(libro.año));
} else {
  console.log("El libro '", libro.titulo, "' es reciente: ", libro.esAntiguo(libro.año));
}
}
console.log("-------------------------------");
console.log("Arrays");
console.log("-------------------------------");

{console.log("Ejercicio 6.1");
  let numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  let double = [];
  for (let i = 0; i < numeros.length; i++){
    double[i] = 2 * numeros[i];
  }
  console.log("Numeros Originales: ", numeros.join(", "));
  console.log("Numeros multiplicados por 2: ", double.join(", "));
  }

console.log("-------------------------------");
{
  console.log("Ejercicio 6.2");
  let pares =[];
  let f=0;
  for (let i=1; i<=20; i++){
    if (i % 2 ==0){
      pares[f]=i;
      f++
    }
  }
  console.log("Primeros 10 numeros pares: ", pares.join(", "));
}
console.log("-------------------------------");
console.log("Dom");
console.log("-------------------------------");
{
*/
console.log("Ejercicio 7.1");
const button = document.getElementById("button");
const contenedor = document.getElementById("contenedor");

button.addEventListener("click",() =>{
  contenedor.classList.add("BlueContenedor");
});
{console.log("Ejercicio 7.2");
  const buttonAlerta = document.getElementById("buttonAlerta");
  const inputTexto = document.getElementById("inputTexto");
  
  buttonAlerta.addEventListener("click", () => {
    const textoIngresado = inputTexto.value;
    const mensaje = alert("Has ingresado: "+ textoIngresado);
  });
  }
  console.log("-------------------------------");
  
  console.log("8.EVENTOS EN DOM");
  {
  console.log("Ejercicio 8.1");
  const elemento1 = document.getElementById("Elemento1");
  const elemento2 = document.getElementById("Elemento2");
  const elemento3 = document.getElementById("Elemento3");
  const elemento4 = document.getElementById("Elemento4");
  
  elemento1.addEventListener("click", () => {
    console.log(elemento1.textContent);
  });
  elemento2.addEventListener("click", () => {
    console.log(elemento2.textContent);
  });
  elemento3.addEventListener("click", () => {
    console.log(elemento3.textContent);
  });
  elemento4.addEventListener("click", () => {
    console.log(elemento4.textContent);
  });
  }
  console.log("-------------------------------");
  
  {console.log("Ejercicio 8.2");
  const deshabilitador = document.getElementById("Deshabilitador");
  const habilitador = document.getElementById("Habilitador");
  const texto = document.getElementById("texto");
  deshabilitador.addEventListener("click", (even) => {
    even.preventDefault();
    texto.disabled = true;
  });
  habilitador.addEventListener("click", (even) => {
    even.preventDefault();
    texto.disabled = false;
  });
  }
  console.log("-------------------------------");
  
  
  console.log("9.LOCALSTORAGE");
  {console.log("Ejercicio 9.1");
  const getDataInputs = () => {
    const email = document.getElementById("email").value;
    if (email.trim() === ""){
      return null;
    }
    localStorage.setItem("datos",
      JSON.stringify({email})
    );
    return email;
  }
  const saveButton = document.getElementById("saveButton");
  const deleteButton = document.getElementById("deleteButton");
  
  saveButton.addEventListener("click", () => {
    
    getDataInputs();
    const result = localStorage.getItem("datos");
    if (result) {
      const emailData = JSON.parse(result);
      console.log(emailData);
      
      const emailDisplay = document.getElementById("emailDisplay");
      emailDisplay.textContent = `Correo guardado: ${emailData.email}`
    } else {
      console.log("No se han ingresado datos");
    }
  });
  
  deleteButton.addEventListener("click", () =>{
    const result = localStorage.getItem("datos");
    if (result){
      localStorage.removeItem("datos");
    } else {
      console.log("No hay datos para eliminar");
    }
  });
  }
  

